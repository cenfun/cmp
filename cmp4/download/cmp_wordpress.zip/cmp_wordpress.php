<?php
/*
Plugin Name: CMP for WordPress
Plugin URI: http://bbs.cenfun.com/
Description: CMP is a free mp3/flv/mp4 music player create by flash. CMP是一款免费的在线Flash音乐播放器，致力于提供最佳在线音乐播放解决方案。主要功能有列表播放，MP3频谱，同步歌词，自定义皮肤，加载各种插件等等，同时支持api接口的调用，让用户实现更多自定义功能.
Version: 1.0
Author: CenFun
Author URI: http://bbs.cenfun.com/
*/
$cmd = $_REQUEST['cmd'];
if ($cmd == 'add') {
	$path = $_REQUEST['path'];
?>
<style type="text/css">
.cmp_table { border:1px solid #CCC; margin-top:10px; font-size:12px; }
.cmp_table th { text-align:right; font-weight:normal; }
.cmp_table th, .cmp_table td { padding:3px 3px; }
.cmp_table .input { width:99%; }
.cmp_table span { color:#666666; }
.cmp_table .codes { width:99%; color:#999; font-size:11px; }
</style>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="cmp_table">
  <tr>
    <th nowrap="nowrap">宽度：</th>
    <td><input id="cmp_width" type="text" value="600" onfocus="this.select()" /></td>
    <th nowrap="nowrap">高度：</th>
    <td><input id="cmp_height" type="text" value="400" onfocus="this.select()" /></td>
    <th nowrap="nowrap">是否透明：</th>
    <td><input type="checkbox" id="cmp_transparent" /></td>
  </tr>
  <tr>
    <th nowrap="nowrap">音乐地址：</th>
    <td colspan="5"><span>填写音乐源的URL地址，也可以从<a href="upload.php" target="_blank">媒体库</a>复制上传的文件地址</span></td>
  </tr>
  <tr>
    <th nowrap="nowrap">src=</th>
    <td colspan="5"><input id="cmp_src" type="text" class="input" value="music/test.mp3" onfocus="this.select()"/></td>
  </tr>
  <tr>
    <th nowrap="nowrap">所有配置：</th>
    <td colspan="5"><span>其他参数可以在下面输入框进行定义，比如：</span></td>
  </tr>
  <tr>
    <th nowrap="nowrap">&nbsp;</th>
    <td colspan="5"><span>自动播放auto_play，皮肤skin，插件plugins等等，url为空表示不加载默认配置<a href="<? echo $path ?>/config.xml" target="_blank">config.xml</a>，lists为空表示不加载默认列表<a href="<? echo $path ?>/list.xml" target="_blank">list.xml</a>，如含有某些特殊字符可能需要<a href="http://tools.cenfun.com/" target="_blank">转义</a>，更多参数详情见<a href="http://cmp.cenfun.com/cmp4/doc/config.htm" title="点击在线查看CMP所有全局配置参数说明" target="_blank">CMP全局配置参数说明</a></span></td>
  </tr>
  <tr>
    <th nowrap="nowrap">&nbsp;</th>
    <td colspan="5"><textarea rows="6" class="input" id="cmp_flashvars">auto_play=1
skin=skins/mini/vplayer.zip
plugins=plugins/sharing.swf
sound_sample=1
url=
lists=
name=CMP
link=</textarea></td>
  </tr>
  <tr>
    <th nowrap="nowrap">标签代码：</th>
    <td colspan="5"><input id="cmp_codes" type="text" class="codes" onfocus="this.select()" /></td>
  </tr>
  <tr>
    <th nowrap="nowrap">&nbsp;</th>
    <td colspan="5"><button id="bt_insert">插入</button>
      <button id="bt_preview">预览</button></td>
  </tr>
</table>
<script type="text/javascript">
(function(){
	var $ = jQuery;
	var path = "<? echo $path ?>";
	function decodeFlashvars(str) {
		var obj = {};
		if (str) {
			str = str.split("\n").join("&");
			var list = str.split("&");
			for (var i = 0; i < list.length; i ++) {
				var item = list[i];
				if (item) {
					var arr = item.split("=");
					var pn = $.trim(arr.shift());
					if (pn && arr.length) {
						var pv = $.trim(arr.join("")) || "";
						if (pv.length >= 2) {
							pv = pv.replace(/^["'](.*)["']$/g, "$1");
						}
						obj[pn] = pv;
					}
				}
			}
		}
		return obj;
	}
	
	function encodeFlashvars(obj) {
		var str = "";
		if (typeof obj == "object") {
			var arr = [];
			for (var i in obj) {
				arr.push(i + "=" + encodeURIComponent(obj[i]));
			}
			arr.sort();
			str = arr.join("&");
		} else {
			str = String(obj);	
		}
		return str;
	}
	
	function makeCodes(check) {
		var cmp_flashvars = $("#cmp_flashvars").val() || "";
		var vars = decodeFlashvars(cmp_flashvars);
		var cmp_src = $("#cmp_src").val() || "";
		if (check && !cmp_src && !vars.list && !vars.lists) {
			if (!confirm("配置中没有设置list或lists列表参数，确定也不填写src音乐地址参数吗？")) {
				return false;
			}
		}
		vars.src = cmp_src;
		var flashvars = encodeFlashvars(vars);
		if (flashvars) {
			var cmp_width = $("#cmp_width").val() || "100%";
			var cmp_height = $("#cmp_height").val() || "100%";
			var cmp_transparent = $("#cmp_transparent:checked").length ? "transparent" : ""
			var cmp_vars = {
				width : cmp_width,
				height : cmp_height,
				flashvars : flashvars
			};
			if (cmp_transparent) {
				cmp_vars.wmode = cmp_transparent;	
			}
			var arr = [];
			for (var i in cmp_vars) {
				arr.push(i + "=\"" + cmp_vars[i] + "\"");	
			}
			var codes = "[cmp " + arr.join(" ") + "]";
			$("#cmp_codes").data("cmp_vars", cmp_vars).val(codes);
			return codes;
		} else {
			return false;	
		}
	}
	
	$("#bt_insert").click(function(e){
		var shortcode = makeCodes(true);
		if (shortcode) {
			if (typeof window.send_to_editor == "function") {
				window.send_to_editor(shortcode);
			} else {
				alert("can not send_to_editor");	
			}
		}
	});
	
	$("#bt_preview").click(function(e){
		var cmp_vars = $("#cmp_codes").data("cmp_vars")
		if (cmp_vars) {
			var url = path + "/cmp.swf?" + cmp_vars.flashvars + "&.swf";
			var str = "width=" + cmp_vars.width + ",height=" + cmp_vars.height + ",resizable=yes";
			window.open(url, "cmp", str);
		}
	});
	
	$("#cmp_width,#cmp_height,#cmp_transparent,#cmp_src,#cmp_flashvars").bind("focus change keyup click", function(e){
		makeCodes();
	});
	
	makeCodes();
	
})();
</script>
<?php
} else {
	if ( !defined('WP_CONTENT_URL') ) {
		define( 'WP_CONTENT_URL', get_option('siteurl') . '/wp-content');
	}
	if ( !defined('WP_PLUGIN_URL') ) {
		define( 'WP_PLUGIN_URL', WP_CONTENT_URL . '/plugins' );
	}
	$dir_name = plugin_basename(dirname(__FILE__));
	$cmp_path = WP_PLUGIN_URL . '/' . $dir_name;
	function add_media_button(){
		global $cmp_path;
		$php_file = basename(__FILE__);
		$page_url = $cmp_path . '/'.$php_file.'?cmd=add&path='.urlencode($cmp_path);
		$button_src = $cmp_path . '/logo.png';
		echo '<a title="Add a CMP" href="'.$page_url.'" class="thickbox">';
		echo '<img src="' . $button_src . '" width="15" height="12" alt="cmp" />';
		echo '</a>';
	}
	function parse_cmp_shortcode($atts) {
		global $cmp_path;
		extract(shortcode_atts(array(
            'width' => '600',
            'height' => '400',
            'flashvars' => '',
            'wmode' => ''
        ), $atts));
		if (substr($width, -1) != "%") {
			$width = $width.'px';	
		}
		if (substr($height, -1) != "%") {
			$height = $height.'px';	
		}
		$key = substr( md5( time() . rand()), 0, 8 );
		$htm = '<div id="player_'.$key.'" style="width:'.$width.';height:'.$height.';"></div>';
		$htm = $htm.'<script type="text/javascript" src="'.$cmp_path.'/cmp.js"></script>';
		$htm = $htm.'<script type="text/javascript">';
		$htm = $htm.'var htm = CMP.create("cmp_'.$key.'", "100%", "100%", "'.$cmp_path.'/cmp.swf", "'.$flashvars.'"';
		if (!empty($wmode)) {
			$htm = $htm.', {wmode:"'.$wmode.'"}';
		}
		$htm = $htm.');';
		$htm = $htm.'document.getElementById("player_'.$key.'").innerHTML = htm;';
		$htm = $htm.'</script>';
		return $htm;
	}
	function cmp_init() {
		add_action('media_buttons', 'add_media_button', 40);
		add_shortcode('cmp', 'parse_cmp_shortcode');
	}
	add_action('plugins_loaded', 'cmp_init');
}

?>
